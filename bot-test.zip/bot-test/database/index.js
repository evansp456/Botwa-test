import fs from "fs"
import path from "path"

const dbPath = path.resolve("./database")

const read = (file) => JSON.parse(fs.readFileSync(path.join(dbPath, file)))
const write = (file, data) => fs.writeFileSync(path.join(dbPath, file), JSON.stringify(data, null, 2))

export const db = {
  read,
  write
}