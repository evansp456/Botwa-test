// utils/helper.js
export const random = (arr) => arr[Math.floor(Math.random() * arr.length)]

export const mentionUser = (jid) => `@${jid.split("@")[0]}`