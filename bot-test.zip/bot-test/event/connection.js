// events/connection.js
export async function connectionEvent(update) {
  const { connection, lastDisconnect } = update

  if (connection === "close") {
    console.log("❌ Connection closed")
  }

  if (connection === "open") {
    console.log("✅ Bot connected")
  }
}