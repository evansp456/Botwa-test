// events/message-update.js
export async function messageUpdateEvent(update) {
  for (const key in update) {
    if (update[key].status === "READ") continue
  }
}