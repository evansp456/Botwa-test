// events/messages.js
export async function messagesEvent(sock, m) {
  const msg = m.messages?.[0]
  if (!msg || !msg.message) return
  if (msg.key.fromMe) return

  const text =
    msg.message.conversation ||
    msg.message.extendedTextMessage?.text ||
    ""

  if (!text.startsWith(".")) return

  const [cmd, ...args] = text.slice(1).split(" ")
  const command = cmd.toLowerCase()

  const handler = global.commands.get(command)
  if (!handler) return

  await handler.execute({ sock, m: msg, args })
}