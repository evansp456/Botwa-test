// events/groups.js
export async function groupsEvent(sock, update) {
  const jid = update.id

  if (update.participants?.length) {
    for (const user of update.participants) {
      if (update.action === "add") {
        await sock.sendMessage(jid, {
          text: `👋 Welcome @${user.split("@")[0]}`,
          mentions: [user]
        })
      }

      if (update.action === "remove") {
        await sock.sendMessage(jid, {
          text: `👋 Goodbye @${user.split("@")[0]}`,
          mentions: [user]
        })
      }
    }
  }
}