// app.js
import { delay } from "./utils/delay.js"
import fs from "fs"
import path from "path"
import { db } from "./database/index.js"

// Scheduler / task runner untuk bot
export const init = async (sock) => {
  try {
    console.log("🔹 App initializing...")

    // Delay awal
    await delay(1000)

    // Load initial data dari database JSON
    const users = db.read("users.json")
    const groups = db.read("groups.json")
    const afk = db.read("afk.json")
    console.log(`🔹 Loaded ${Object.keys(users).length} users`)
    console.log(`🔹 Loaded ${Object.keys(groups).length} groups`)
    console.log(`🔹 Loaded ${Object.keys(afk).length} AFK entries`)

    // Contoh scheduler: notify prayer setiap menit
    setInterval(async () => {
      try {
        const prayerData = db.read("prayer.json")
        for (const jid in prayerData) {
          const data = prayerData[jid]
          if (!data.notified && Date.now() >= data.time) {
            await sock.sendMessage(jid, { text: `🕌 Waktunya sholat: ${data.name}` })
            data.notified = true
          }
        }
        db.write("prayer.json", prayerData)
      } catch (err) {
        console.error("Error in prayer scheduler:", err)
      }
    }, 60000) // check every 60 sec

    // Log ready
    console.log("🔹 Bot ready and scheduler running")
  } catch (err) {
    // Simpan error ke logs
    const logPath = path.resolve("./logs/problem.log")
    const log = `[${new Date().toISOString()}] APP INIT ERROR: ${err.stack}\n`
    fs.appendFileSync(logPath, log)
    console.error(err)
  }
}