// index.js
import { startCore } from "./core/baileys.js"
import { messagesEvent } from "./events/messages.js"
import { groupsEvent } from "./events/groups.js"
import { connectionEvent } from "./events/connection.js"
import { messageUpdateEvent } from "./events/message-update.js"
import { init as appInit } from "./app.js"

import fs from "fs"
import path from "path"

// GLOBAL COMMANDS
global.commands = new Map()

// LOAD COMMANDS
const loadCommands = async (dir) => {
  for (const file of fs.readdirSync(dir)) {
    const full = path.join(dir, file)
    if (fs.statSync(full).isDirectory()) await loadCommands(full)
    else if (file.endsWith(".js")) {
      const cmd = (await import(path.resolve(full))).default
      if (cmd && cmd.name) global.commands.set(cmd.name, cmd)
    }
  }
}
await loadCommands("./commands")

// REPAIR CODE / SESSION
const repairCode = process.env.REPAIR_CODE || ""
if (repairCode) console.log("🔹 Using repair code...")

// START CORE
const sock = await startCore({ repairCode })

// CALL APP INIT (scheduler / task runner)
await appInit(sock)

// EVENT LISTENER
sock.ev.on("messages.upsert", (m) => messagesEvent(sock, m))
sock.ev.on("group-participants.update", (u) => groupsEvent(sock, u))
sock.ev.on("connection.update", (u) => connectionEvent(u))
sock.ev.on("messages.update", (u) => messageUpdateEvent(u))

console.log("✅ Bot is running...")