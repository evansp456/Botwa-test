// core/connection.js
import { DisconnectReason } from "@whiskeysockets/baileys"
import { createSocket } from "./baileys.js"

export function registerConnection(sock) {
  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect } = update
    if (connection === "close") {
      const code = lastDisconnect?.error?.output?.statusCode
      if (code !== DisconnectReason.loggedOut) {
        await createSocket()
      }
    }
  })
}