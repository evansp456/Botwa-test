// core/scheduler.js
import cron from "node-cron"

export function startScheduler(task) {
  cron.schedule("* * * * *", async () => {
    await task()
  })
}