// config/group.js
export const groupConfig = {
  welcome: true,    // on/off welcome
  goodbye: true,    // on/off goodbye
  antilink: false,  // on/off antilink
  lock: false       // on/off lockgroup
}