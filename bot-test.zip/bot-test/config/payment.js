// config/payment.js
export const paymentMethods = {
  dana: "tanya admin"
  gopay: "089660132225",
  ovo: "ga ada"
}