// config/main.js
export const owner = ["6289660132225"] // ganti nomor owner tanpa +
export const botName = "EvanBot"
export const prefix = "."