// config/prayer.js
export const prayerConfig = {
  enable: true,         // notif sholat on/off
  location: "Jakarta",  // bisa diganti kota lain
  method: 3             // metode perhitungan sholat
}