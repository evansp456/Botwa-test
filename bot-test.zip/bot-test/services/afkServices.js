// services/afkService.js
import fs from "fs"

const file = "./database/afk.json"

const read = () => JSON.parse(fs.readFileSync(file))
const write = (d) => fs.writeFileSync(file, JSON.stringify(d, null, 2))

export const setAfk = (jid, reason = "") => {
  const db = read()
  db[jid] = { reason, time: Date.now() }
  write(db)
}

export const getAfk = (jid) => {
  const db = read()
  return db[jid] || null
}

export const clearAfk = (jid) => {
  const db = read()
  delete db[jid]
  write(db)
}