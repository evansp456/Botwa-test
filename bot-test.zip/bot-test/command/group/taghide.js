// commands/group/taghide.js
export default {
  name: "taghide",
  execute: async ({ sock, m }) => {
    const meta = await sock.groupMetadata(m.key.remoteJid)
    const members = meta.participants.map(p => p.id)
    await sock.sendMessage(m.key.remoteJid, {
      text: "Hidden tag",
      mentions: members
    })
  }
}