// commands/group/lockgroup.js
export default {
  name: "lockgroup",
  execute: async ({ sock, m }) => {
    await sock.groupSettingUpdate(m.key.remoteJid, "announcement")
    await sock.sendMessage(m.key.remoteJid, { text: "Group locked" })
  }
}