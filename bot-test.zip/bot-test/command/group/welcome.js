// commands/group/welcome.js
export default {
  name: "welcome",
  execute: async ({ sock, m }) => {
    await sock.sendMessage(m.key.remoteJid, { text: "Welcome admin ON" })
  }
}