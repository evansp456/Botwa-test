// commands/group/antilink.js
export default {
  name: "antilink",
  execute: async ({ sock, m }) => {
    await sock.sendMessage(m.key.remoteJid, { text: "Antilink ON" })
  }
}