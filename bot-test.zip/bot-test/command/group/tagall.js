// commands/group/tagall.js
export default {
  name: "tagall",
  execute: async ({ sock, m }) => {
    const meta = await sock.groupMetadata(m.key.remoteJid)
    const members = meta.participants.map(p => p.id)
    await sock.sendMessage(m.key.remoteJid, {
      text: "Tag All",
      mentions: members
    })
  }
}