// commands/public/help.js
export default {
  name: "help",
  execute: async ({ sock, m }) => {
    await sock.sendMessage(m.key.remoteJid, {
      text: `
📌 CARA PAKAI BOT

• Ketik .menu → lihat semua fitur
• Ketik .ping → cek bot hidup
• Perintah diawali titik (.)

📂 GROUP
• Beberapa fitur cuma bisa dipakai ADMIN

📂 OWNER
• Khusus owner bot

Kalau error / ga respon:
→ restart bot
→ pastiin bot jadi admin
      `
    })
  }
}