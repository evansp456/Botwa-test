// commands/public/info.js
export default {
  name: "info",
  execute: async ({ sock, m }) => {
    await sock.sendMessage(m.key.remoteJid, { text: "Bot WhatsApp Baileys" })
  }
}