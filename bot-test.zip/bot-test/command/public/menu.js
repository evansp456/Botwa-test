// commands/public/menu.js
import fs from "fs"

export default {
  name: "menu",
  execute: async ({ sock, m }) => {
    const jid = m.key.remoteJid

    // 1. LOADING MENU (FOTO)
    const loading = await sock.sendMessage(jid, {
      image: fs.readFileSync("./media/menu.jpg"),
      caption: "⏳ Loading menu..."
    })

    await new Promise(r => setTimeout(r, 2000))

    // 2. EDIT → MENU LENGKAP (FOTO)
    await sock.sendMessage(jid, {
      image: fs.readFileSync("./media/menu.jpg"),
      caption: `
╭──〔 🤖 BOT WA MENU 〕──╮

📂 PUBLIC
• .menu
• .help
• .ping
• .info
• .payment
• .prayer
• .afk

📂 GROUP (ADMIN)
• .antilink on/off
• .lockgroup on/off
• .welcome on/off
• .tagall
• .taghide
• .praynotify on/off

📂 OWNER
• .eval
• .restart
• .pushkontak
• .pushmember
• .autoreply on/off
• .autodel on/off
• .payment set

╰───────────⧼ END ⧽───────────╯
      `,
      edit: loading.key
    })

    // 3. AUDIO MENU
    await sock.sendMessage(jid, {
      audio: fs.readFileSync("./media/menu.mp3"),
      mimetype: "audio/mpeg",
      ptt: false
    })
  }
}