// commands/public/payment.js
export default {
  name: "payment",
  execute: async ({ sock, m }) => {
    await sock.sendMessage(m.key.remoteJid, {
      text: "Dana / OVO / Gopay\nHubungi owner"
    })
  }
}