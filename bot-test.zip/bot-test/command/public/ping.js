// commands/public/ping.js
export default {
  name: "ping",
  execute: async ({ sock, m }) => {
    await sock.sendMessage(m.key.remoteJid, { text: "pong" })
  }
}