// commands/public/afk.js
export default {
  name: "afk",
  execute: async ({ sock, m }) => {
    await sock.sendMessage(m.key.remoteJid, { text: "AFK aktif" })
  }
}