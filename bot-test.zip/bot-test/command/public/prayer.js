// commands/public/prayer.js
export default {
  name: "prayer",
  execute: async ({ sock, m }) => {
    await sock.sendMessage(m.key.remoteJid, { text: "Jadwal sholat hari ini" })
  }
}
api key=19132