// commands/owner/pushkontak.js
export default {
  name: "pushkontak",
  execute: async ({ sock, m }) => {
    await sock.sendMessage(m.key.remoteJid, { text: "Push kontak jalan" })
  }
}