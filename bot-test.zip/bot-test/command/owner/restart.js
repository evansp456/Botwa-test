// commands/owner/restart.js
export default {
  name: "restart",
  execute: async () => {
    process.exit(0)
  }
}