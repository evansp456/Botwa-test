// commands/owner/pushmember.js
export default {
  name: "pushmember",
  execute: async ({ sock, m }) => {
    await sock.sendMessage(m.key.remoteJid, { text: "Push member jalan" })
  }
}