// commands/owner/payment.js
export default {
  name: "payment",
  execute: async ({ sock, m }) => {
    await sock.sendMessage(m.key.remoteJid, {
      text: "Metode pembayaran owner"
    })
  }
}