// commands/owner/autodel.js
export default {
  name: "autodel",
  execute: async ({ sock, m }) => {
    await sock.sendMessage(m.key.remoteJid, { text: "Auto delete ON" })
  }
}