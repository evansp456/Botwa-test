// commands/owner/eval.js
export default {
  name: "eval",
  execute: async ({ sock, m, args }) => {
    try {
      const res = eval(args.join(" "))
      await sock.sendMessage(m.key.remoteJid, { text: String(res) })
    } catch (e) {
      await sock.sendMessage(m.key.remoteJid, { text: String(e) })
    }
  }
}