// middlewares/cooldown.js
const cd = new Map()

export default function cooldown(jid, time = 3000) {
  const now = Date.now()
  if (cd.has(jid) && now - cd.get(jid) < time) return true
  cd.set(jid, now)
  return false
}