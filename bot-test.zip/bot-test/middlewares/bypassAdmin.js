// middlewares/bypassAdmin.js
import isOwner from "./isOwner.js"

export default function bypassAdmin(jid) {
  return isOwner(jid)
}