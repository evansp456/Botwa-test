// middlewares/isOwner.js
import { owner } from "../config/main.js"

export default function isOwner(jid) {
  return owner.includes(jid.split("@")[0])
}