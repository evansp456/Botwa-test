// middlewares/isBotAdmin.js
export default async function isBotAdmin(sock, jid) {
  const meta = await sock.groupMetadata(jid)
  const botId = sock.user.id.split(":")[0] + "@s.whatsapp.net"
  return meta.participants.some(
    p => p.id === botId && p.admin
  )
}