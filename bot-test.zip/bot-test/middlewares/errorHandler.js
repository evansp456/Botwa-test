// middlewares/errorHandler.js
import fs from "fs"

export default function errorHandler(err) {
  const log = `[${new Date().toISOString()}] ${err.stack}\n`
  fs.appendFileSync("./logs/problem.log", log)
  console.error(err)
}